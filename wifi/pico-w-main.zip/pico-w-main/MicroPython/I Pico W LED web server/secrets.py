secrets = {
    'ssid': 'Replace-this-with-your-Wi-Fi-Name',
    'pw': 'Replace-this-with-your-Wi-Fi-Password'
    }