V Pico W PWM servo controller
=============================

The Pico W can control servo motors with PWM.<br>
Get started by watching our [video guide](https://youtu.be/z0H_C-8XeY4).
