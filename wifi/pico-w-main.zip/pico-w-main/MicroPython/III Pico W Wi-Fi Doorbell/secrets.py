secrets = {
    'ssid': 'Replace-this-with-your-SSID',
    'pw': 'Replace-this-with-your-Password',
    'ifttt_key': 'Replace-this-with-your-IFTTT-Key'
    }
